/* eslint-disable no-unused-vars */
import { AppBar, Box, Toolbar, Typography, Button } from "@mui/material";

import { NavLink,useNavigate } from "react-router-dom";
import "./AdminLogin.css";

import Pic1 from '../../images/Pic1.png';
import "./Contact.css"
import {complaint} from "./Complaints.js"
import { collection, FieldValue } from "firebase/firestore";
import React,{ useState, useEffect } from "react";
import { db } from './firebaseConfig'
import { getDocs, addDoc, doc, deleteDoc} from "firebase/firestore"
import { async } from "@firebase/util";

const AdminLogin = () => {
    
       const navigate = useNavigate();
       
       const handleAnnouncement=()=>{
           navigate("/Announcement");
       }

return (
    <>

    <div className="d-flex" id="wrapper">

        
        <div className="bg-white" id="sidebar-wrapper">
            <div className="sidebar-heading text-center py-4 primary-text fs-4 fw-bold text-uppercase border-bottom"><i
                    className="fas fa-user-secret me-2"></i>MANITVERSE</div>
            <div className="list-group list-group-flush my-3">
                <a href="/" className="list-group-item list-group-item-action bg-transparent second-text "><i
                        className="fas fa-tachometer-alt me-2"></i>Home</a>
                        
                        
       
                <a href="\Announcement.js" className="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                         ANNOUNCEMENTS 
                </a>

                <a href="/" className="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                <i class="fa-solid fa-address-book"></i>STUDENTS LIST</a>
                <a href="/" className="list-group-item list-group-item-action bg-transparent second-text fw-bold">
                <i class="fa-solid fa-address-book"></i>MESS MENU</a>
                <a href="/" className="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                        className="fas fa-shopping-cart me-2"></i>INVENTORY</a>
                <a href="/" className="list-group-item list-group-item-action bg-transparent text-danger fw-bold"><i
                        className="fas fa-power-off me-2"></i>Logout</a>
            </div>
        </div>
       
       <div id="page-content-wrapper">
       
            <nav class="navbar navbar-expand-lg navbar-light  py-4 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle"></i>
                    <h2 class="fs-2 m-0">Dashboard</h2>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text fw-bold" href="/" id="navbarDropdown"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>RAJNEESH
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="/">Profile</a></li>
                                <li><a class="dropdown-item" href="/">Settings</a></li>
                                <li><a class="dropdown-item" href="/">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

        
        
        </div>
  
</div>

    </>
);
  };
  export default AdminLogin;
  